package nyp_8;



public class Main {

    static MainScreen mainScreen;

	public static void main(String[] args) {
	
	    mainScreen = new MainScreen();
	    mainScreen.setVisible(true);
      
    }



}